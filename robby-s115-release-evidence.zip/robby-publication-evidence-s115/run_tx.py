import hashlib, json, sys, traceback
sys.path.insert(0, '/workspace/Robby/scripts')
import transact_wind_step_publication as tx
R = '/workspace/redeliver/'
def pin(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()
paths = {
    'manifest': R + 'stage/manifest.json', 'place': R + 'stage/WindStepPublishedStage.rbxl',
    'consent': R + 'consent.json', 'review': R + 'review.json',
    'source': '/workspace/Robby/research/inbox/2026-11-01-S106-publication-approval.md',
}
expected = {'manifest': 'e130f568cecf8302fa9a5a3b4f03ba8832605f7cace337fe541659799b7f50b3',
            'place': '35b43b5fd464bbc78cf97b8adb4421e1e0e8436cdc5d376c5b1ed81fa081693f',
            'source': '376e1d492c9f466cebdbadf63494d9a4c1f893022263bc79b412903d6a4e889a'}
inputs = {}
for k, p in paths.items():
    h = expected.get(k) or pin(p)
    assert pin(p) == h, k
    inputs[k] = (p, h)
execute = sys.argv[1] == 'execute'
spool = sys.argv[2]
try:
    r = tx.transact(inputs, spool, owner_sources_reviewed=execute)
    print(json.dumps(r, sort_keys=True)[:3000])
except Exception as e:
    print('EXC', type(e).__name__, str(e)[:600])
    traceback.print_exc(limit=3)
