import calendar, hashlib, json, time
target = json.load(open('/workspace/redeliver/stage/target.json'))
def ts(s):
    return calendar.timegm(time.strptime(s, '%Y-%m-%dT%H:%M:%SZ'))
issued = ts('2026-11-02T15:21:17Z')
consent = {
    "schema": 1, "kind": "Owner consent for isolated test overwrite and publication",
    "target": target,
    "manifestSha256": "e130f568cecf8302fa9a5a3b4f03ba8832605f7cace337fe541659799b7f50b3",
    "placeSha256": "35b43b5fd464bbc78cf97b8adb4421e1e0e8436cdc5d376c5b1ed81fa081693f",
    "ownerUserId": target["ownerUserId"],
    "authorizeTestPublication": True, "acknowledgeOverwrite": True,
    "issuedAt": issued, "expiresAt": issued + 86400,
    "sourceReference": "PromptQL bot ed1828b3-108b-4a9b-a6ae-9d7776920c76: owner (user 52c55237-5ac7-4344-b054-37bcd5561339) replied 'Yes' 2026-11-02T15:21:17Z to CTA 20f81d95-4a06-43e8-adca-b3fecba83a3f on bot message 2486126e-fd82-4806-be23-7e56d523da4c approving T-050 card (source 66fcf98, archive 2680c3dd, manifest e130f568, place 35b43b5f)",
}
src = open('/workspace/Robby/research/inbox/2026-11-01-S106-publication-approval.md', 'rb').read()
att = ts('2026-11-01T17:15:39Z')
review = {
    "schema": 2, "kind": "Owner declaration of isolated test API permissions; dashboard evidence waived",
    "integrationId": "roblox-open-cloud", "target": target,
    "attestedByOwnerUserId": target["ownerUserId"], "credentialBindingConfirmed": True,
    "publicationScope": "universe-places", "publicationOperation": "Write", "historyScope": "universe.place:read",
    "attestedAt": att, "expiresAt": att + 86400,
    "sourceReference": "research/inbox/2026-11-01-S106-publication-approval.md (owner declaration 2026-11-01T17:15:39.438Z, verbatim)",
    "sourceSha256": hashlib.sha256(src).hexdigest(), "dashboardEvidenceWaived": True,
}
for name, obj in (('consent', consent), ('review', review)):
    raw = json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()
    open(f'/workspace/redeliver/{name}.json', 'wb').write(raw)
    print(name, hashlib.sha256(raw).hexdigest())
print('source', hashlib.sha256(src).hexdigest(), 'now', int(time.time()), 'reviewExpires', att + 86400)
