import hashlib, json, sys, traceback
sys.path.insert(0, '/workspace/Robby/scripts')
import transact_wind_step_publication as tx
R = '/workspace/robby-T051a-stage/'
def pin(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()
paths = {'manifest': R + 'manifest.json', 'place': R + 'WindStepPlayStage.rbxl', 'consent': R + 'consent.json',
         'review': R + 'review.json', 'source': '/workspace/Robby/research/inbox/2026-11-01-S106-publication-approval.md'}
expected = {'manifest': '784282e121dcf156b157bc836aba956c2ad09816555164822f0f3d266d5900b3',
            'place': '4b7fecd87062a42f33e9031b81ed46e73721701c19e95f49d539b7f603451ece',
            'source': '376e1d492c9f466cebdbadf63494d9a4c1f893022263bc79b412903d6a4e889a'}
inputs = {}
for k, p in paths.items():
    h = expected.get(k) or pin(p)
    assert pin(p) == h, k
    inputs[k] = (p, h)
try:
    r = tx.transact(inputs, sys.argv[2], owner_sources_reviewed=(sys.argv[1] == 'execute'))
    print(json.dumps(r, sort_keys=True)[:3000])
except Exception as e:
    print('EXC', type(e).__name__, str(e)[:600])
    traceback.print_exc(limit=3)
