import calendar, hashlib, json, time
R = '/workspace/robby-T051a-stage/'
target = json.load(open(R + 'S100-wind-step-target.json'))
def ts(s):
    return calendar.timegm(time.strptime(s, '%Y-%m-%dT%H:%M:%SZ'))
issued = ts('2026-11-02T16:23:19Z')
consent = {
    "schema": 1, "kind": "Owner consent for isolated test overwrite and publication", "target": target,
    "manifestSha256": "784282e121dcf156b157bc836aba956c2ad09816555164822f0f3d266d5900b3",
    "placeSha256": "4b7fecd87062a42f33e9031b81ed46e73721701c19e95f49d539b7f603451ece",
    "ownerUserId": target["ownerUserId"], "authorizeTestPublication": True, "acknowledgeOverwrite": True,
    "issuedAt": issued, "expiresAt": issued + 86400,
    "sourceReference": "PromptQL bot 065f4ba4-57b3-4e38-aeea-bfa6da7f8181: user d04e063e-f828-4299-bc1b-0d918d64a26b replied 'Yes' 2026-11-02T16:23:19Z to CTA 21bf0d33-2dff-49ac-a47a-97eef2541ae7 on bot message 59a89b63-508c-4394-80f7-c5af08a36afa approving T-051a play card robby_t051a_approval (main d67ff30, manifest 784282e1, place 4b7fecd8)",
}
src = open('/workspace/Robby/research/inbox/2026-11-01-S106-publication-approval.md', 'rb').read()
att = ts('2026-11-01T17:15:39Z')
review = {
    "schema": 2, "kind": "Owner declaration of isolated test API permissions; dashboard evidence waived",
    "integrationId": "roblox-open-cloud", "target": target,
    "attestedByOwnerUserId": target["ownerUserId"], "credentialBindingConfirmed": True,
    "publicationScope": "universe-places", "publicationOperation": "Write", "historyScope": "universe.place:read",
    "attestedAt": att, "expiresAt": att + 86400,
    "sourceReference": "research/inbox/2026-11-01-S106-publication-approval.md (owner declaration 2026-11-01T17:15:39.438Z, verbatim)",
    "sourceSha256": hashlib.sha256(src).hexdigest(), "dashboardEvidenceWaived": True,
}
for name, obj in (('consent', consent), ('review', review)):
    raw = json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()
    open(R + name + '.json', 'wb').write(raw)
    print(name, hashlib.sha256(raw).hexdigest())
print('source', hashlib.sha256(src).hexdigest(), 'now', int(time.time()), 'reviewExpires', att + 86400)
